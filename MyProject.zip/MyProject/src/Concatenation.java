
public class Concatenation {
	public static void main(String args[]){
		String part1Str = "Good";
		String part2Str = "Day";
		String resultStr;
		
		resultStr = concatenate(part1Str, part2Str);
		System.out.println("Concat result: " + resultStr);
	}
	//public static void concatenate(String leftStr, String rightStr){
	public static String concatenate(String leftStr, String rightStr){
		String concatStr;
		
		concatStr = leftStr + " " + rightStr;
		return concatStr;
	}

}
