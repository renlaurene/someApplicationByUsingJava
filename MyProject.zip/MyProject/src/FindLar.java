
public class FindLar {
	public static void main(String arg[]){
		
		int sizes[] = {4,10,15,20};
		int larNum;
		double sum = 0.0;
		int numElems;
		
		numElems = sizes.length;
		larNum = sizes[0];
		
		for(int i=0; i<numElems; i++){
			if (larNum > sizes[i]);{
				System.out.println("The largetst number is:   " + larNum);
			}
		}
		System.out.println("The largetst number is:   " + larNum);
	}
}
