
public class Calculator {
	public static void main(String args[]){
		int val = 5;
		int result;
		
		result = cube(val);
		System.out.println("Cube result: " + result);
	}
	//public static void cube(int num){
	public static int cube(int num){
		return num*num*num;
	}
}
