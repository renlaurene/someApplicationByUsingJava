import java.util.Scanner;


public class FindAverage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner stdin;
		double sizes[] = {4.5,10.2,15.467,20.718};
		double sum = 0.0;
		int numElems = 1;
		double avg;
		
			
		// Get a integer form the user 
		
		stdin = new Scanner(System.in);
		System.out.println("Enter your number: ");
		//userNum = stdin.nextInt();
		
		
		for (int i = 0; i < numElems; i++){			
		}
		avg = sum /numElems; 
		System.out.println("Average: " + avg);
	}

}
