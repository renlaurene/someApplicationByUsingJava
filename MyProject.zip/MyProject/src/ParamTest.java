
public class ParamTest {
		static void resetLastElem(int ary[]){
			ary[ary.length-1] = 0;
		}
		public static void main(String args[]){
			int intAry[] = {1,2,3};
			resetLastElem(intAry);
			
			System.out.println(intAry[0] + "," + intAry[2]);
		}

	}
